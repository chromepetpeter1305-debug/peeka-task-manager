import 'package:flutter/material.dart';
import '../services/notification_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.isDark, required this.onThemeChanged});
  final bool isDark;
  final ValueChanged<bool> onThemeChanged;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: SwitchListTile(
        secondary: const Icon(Icons.dark_mode_outlined),
        title: const Text('Dark theme'),
        subtitle: const Text('Use Peeka’s dark purple look'),
        value: isDark,
        onChanged: onThemeChanged,
      )),
      Card(child: ListTile(
        leading: const Icon(Icons.notifications_outlined),
        title: const Text('Notification permission'),
        subtitle: const Text('Allow Peeka to send task reminders'),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () async {
          final granted = await NotificationService.instance.requestPermission();
          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(granted ? 'Notification permission granted' : 'Permission not granted. Enable notifications in Android Settings.')),
          );
        },
      )),
      const Card(child: ListTile(
        leading: Icon(Icons.info_outline_rounded),
        title: Text('About Peeka'),
        subtitle: Text('Your tasks, your pace. Stored locally on this device.'),
      )),
    ]),
  );
}
