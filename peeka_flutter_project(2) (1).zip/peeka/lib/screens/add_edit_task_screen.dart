import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import '../database/task_database.dart';
import '../models/task.dart';
import '../services/notification_service.dart';

class AddEditTaskScreen extends StatefulWidget {
  const AddEditTaskScreen({super.key, this.task});
  final PeekaTask? task;

  @override
  State<AddEditTaskScreen> createState() => _AddEditTaskScreenState();
}

class _AddEditTaskScreenState extends State<AddEditTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _description;
  DateTime? _dueAt;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: widget.task?.title ?? '');
    _description = TextEditingController(text: widget.task?.description ?? '');
    _dueAt = widget.task?.dueAt;
  }

  @override
  void dispose() { _title.dispose(); _description.dispose(); super.dispose(); }

  Future<void> _pickDateTime() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context, initialDate: _dueAt ?? now,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 10),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_dueAt ?? now));
    if (time == null || !mounted) return;
    setState(() => _dueAt = DateTime(date.year, date.month, date.day, time.hour, time.minute));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _saving) return;
    setState(() => _saving = true);
    try {
      final old = widget.task;
      final task = PeekaTask(
        id: old?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: _title.text.trim(),
        description: _description.text.trim(),
        isCompleted: old?.isCompleted ?? false,
        createdAt: old?.createdAt ?? DateTime.now(),
        dueAt: _dueAt,
        reminderId: old?.reminderId,
      );
      if (old == null) {
        await TaskDatabase.instance.insert(task);
      } else {
        await NotificationService.instance.cancelTask(old);
        await TaskDatabase.instance.update(task);
      }
      await NotificationService.instance.schedule(task);
      if (mounted) Navigator.pop(context, true);
    } on PlatformException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save task: ${e.message ?? e.code}')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not save task: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.task == null ? 'New task' : 'Edit task')),
    body: SafeArea(child: Form(
      key: _formKey,
      child: ListView(padding: const EdgeInsets.all(20), children: [
        Text('What do you want to do?', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 20),
        TextFormField(controller: _title, autofocus: true, maxLength: 100,
          decoration: const InputDecoration(labelText: 'Task title', hintText: 'e.g. Finish assignment'),
          validator: (v) => v == null || v.trim().isEmpty ? 'Please enter a task title' : null),
        const SizedBox(height: 12),
        TextFormField(controller: _description, maxLines: 4, maxLength: 500,
          decoration: const InputDecoration(labelText: 'Description (optional)', alignLabelWithHint: true)),
        const SizedBox(height: 12),
        Card(child: ListTile(
          leading: const Icon(Icons.notifications_active_outlined),
          title: Text(_dueAt == null ? 'No reminder set' : 'Reminder'),
          subtitle: Text(_dueAt == null ? 'Choose a due date and time' : MaterialLocalizations.of(context).formatFullDate(_dueAt!) + ' · ' + TimeOfDay.fromDateTime(_dueAt!).format(context)),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: _pickDateTime,
        )),
        if (_dueAt != null) Align(alignment: Alignment.centerLeft, child: TextButton.icon(
          onPressed: () => setState(() => _dueAt = null),
          icon: const Icon(Icons.close_rounded), label: const Text('Remove reminder'))),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: _saving ? null : _save,
          icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.check_rounded),
          label: Text(_saving ? 'Saving…' : 'Save task'),
        ),
      ]),
    )),
  );
}
