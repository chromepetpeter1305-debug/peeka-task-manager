import 'package:flutter/material.dart';
import '../database/task_database.dart';
import '../models/task.dart';
import '../services/notification_service.dart';
import '../theme/app_theme.dart';
import '../widgets/task_card.dart';
import '../widgets/empty_state.dart';
import 'add_edit_task_screen.dart';
import 'settings_screen.dart';

enum TaskFilter { all, pending, completed }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.isDark, required this.onThemeChanged});
  final bool isDark;
  final ValueChanged<bool> onThemeChanged;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<PeekaTask> _tasks = [];
  TaskFilter _filter = TaskFilter.all;
  String _query = '';
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final tasks = await TaskDatabase.instance.getAll();
      if (mounted) setState(() { _tasks = tasks; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<PeekaTask> get _visible {
    final result = _tasks.where((t) {
      final matches = t.title.toLowerCase().contains(_query.toLowerCase());
      final filter = _filter == TaskFilter.all ||
          (_filter == TaskFilter.pending && !t.isCompleted) ||
          (_filter == TaskFilter.completed && t.isCompleted);
      return matches && filter;
    }).toList();
    result.sort((a, b) {
      if (a.dueAt == null && b.dueAt == null) return b.createdAt.compareTo(a.createdAt);
      if (a.dueAt == null) return 1;
      if (b.dueAt == null) return -1;
      return a.dueAt!.compareTo(b.dueAt!);
    });
    return result;
  }

  Future<void> _edit([PeekaTask? task]) async {
    final changed = await Navigator.push<bool>(context, MaterialPageRoute(
      builder: (_) => AddEditTaskScreen(task: task),
    ));
    if (changed == true) await _load();
  }

  Future<void> _toggle(PeekaTask task, bool done) async {
    final updated = task.copyWith(isCompleted: done);
    await TaskDatabase.instance.update(updated);
    if (done) {
      await NotificationService.instance.cancelTask(task);
    } else {
      await NotificationService.instance.schedule(updated);
    }
    await _load();
  }

  Future<void> _delete(PeekaTask task) async {
    final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Delete task?'),
      content: Text('“${task.title}” will be permanently removed.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
      ],
    ));
    if (confirm != true) return;
    await NotificationService.instance.cancelTask(task);
    await TaskDatabase.instance.delete(task.id);
    await _load();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Task deleted')));
  }

  @override
  Widget build(BuildContext context) {
    final completed = _tasks.where((t) => t.isCompleted).length;
    final pending = _tasks.length - completed;
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(width: 36, height: 36, decoration: BoxDecoration(
            color: AppTheme.purple, borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.check_rounded, color: Colors.white)),
          const SizedBox(width: 10),
          const Text('Peeka', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.5)),
        ]),
        actions: [IconButton(tooltip: 'Settings', icon: const Icon(Icons.settings_outlined),
          onPressed: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => SettingsScreen(isDark: widget.isDark, onThemeChanged: widget.onThemeChanged),
          ))],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add task'),
      ),
      body: SafeArea(child: _loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 100), children: [
          Text('Make today count.', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text('Small steps. Big progress.', style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          const SizedBox(height: 20),
          Row(children: [
            _StatCard(label: 'Total', value: '${_tasks.length}', icon: Icons.list_alt_rounded),
            const SizedBox(width: 10),
            _StatCard(label: 'Pending', value: '$pending', icon: Icons.timelapse_rounded),
            const SizedBox(width: 10),
            _StatCard(label: 'Done', value: '$completed', icon: Icons.check_circle_outline_rounded),
          ]),
          const SizedBox(height: 20),
          TextField(
            onChanged: (value) => setState(() => _query = value),
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Search tasks'),
          ),
          const SizedBox(height: 14),
          SegmentedButton<TaskFilter>(
            segments: const [
              ButtonSegment(value: TaskFilter.all, label: Text('All')),
              ButtonSegment(value: TaskFilter.pending, label: Text('Pending')),
              ButtonSegment(value: TaskFilter.completed, label: Text('Completed')),
            ],
            selected: {_filter},
            onSelectionChanged: (value) => setState(() => _filter = value.first),
          ),
          const SizedBox(height: 16),
          if (_visible.isEmpty)
            const EmptyState()
          else
            ..._visible.map((task) => TaskCard(
              task: task,
              onToggle: (value) => _toggle(task, value),
              onEdit: () => _edit(task),
              onDelete: () => _delete(task),
            )),
        ]),
      )),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.value, required this.icon});
  final String label, value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Expanded(child: Card(child: Padding(
    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
    child: Column(children: [
      Icon(icon, color: AppTheme.purple, size: 20),
      const SizedBox(height: 6),
      Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      Text(label, style: Theme.of(context).textTheme.labelMedium),
    ]),
  )));
}
