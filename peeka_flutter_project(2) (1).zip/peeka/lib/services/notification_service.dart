import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../models/task.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();
    try {
      final zone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(zone.identifier));
    } catch (_) {
      tz.setLocalLocation(tz.local);
    }
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);
    const channel = AndroidNotificationChannel(
      'peeka_task_reminders',
      'Task reminders',
      description: 'Reminders for your Peeka tasks',
      importance: Importance.max,
    );
    await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    _initialized = true;
  }

  Future<bool> requestPermission() async {
    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    return await android?.requestNotificationsPermission() ?? true;
  }

  Future<void> schedule(PeekaTask task) async {
    await cancel(task.reminderId ?? _notificationId(task.id));
    final due = task.dueAt;
    if (task.isCompleted || due == null || !due.isAfter(DateTime.now())) return;
    final permitted = await requestPermission();
    if (!permitted) return;
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        'peeka_task_reminders',
        'Task reminders',
        channelDescription: 'Reminders for your Peeka tasks',
        importance: Importance.max,
        priority: Priority.high,
        styleInformation: BigTextStyleInformation(
          task.description.isEmpty ? 'It is time for your task.' : task.description,
        ),
      ),
    );
    await _plugin.zonedSchedule(
      _notificationId(task.id),
      task.title,
      'Your Peeka task is due now.',
      tz.TZDateTime.from(due, tz.local),
      details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: task.id,
    );
  }

  int _notificationId(String id) => id.hashCode & 0x7fffffff;

  Future<void> cancel(int id) => _plugin.cancel(id);

  Future<void> cancelTask(PeekaTask task) async {
    await cancel(task.reminderId ?? _notificationId(task.id));
  }
}
