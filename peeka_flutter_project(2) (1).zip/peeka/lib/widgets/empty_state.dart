import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 54, horizontal: 20),
    child: Column(children: [
      Container(width: 84, height: 84, decoration: BoxDecoration(
        color: AppTheme.purple.withValues(alpha: .14), borderRadius: BorderRadius.circular(28)),
        child: const Icon(Icons.task_alt_rounded, size: 42, color: AppTheme.purple)),
      const SizedBox(height: 18),
      Text('Nothing on your list yet', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Text('Add a task and Peeka will help you keep it in sight.',
        textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
    ]),
  );
}
