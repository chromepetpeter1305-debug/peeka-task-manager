import 'package:flutter/material.dart';
import '../models/task.dart';
import '../theme/app_theme.dart';

class TaskCard extends StatelessWidget {
  const TaskCard({super.key, required this.task, required this.onToggle, required this.onEdit, required this.onDelete});
  final PeekaTask task;
  final ValueChanged<bool> onToggle;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final due = task.dueAt;
    final overdue = !task.isCompleted && due != null && due.isBefore(DateTime.now());
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Checkbox(value: task.isCompleted, onChanged: (v) => onToggle(v ?? false), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6))),
          Expanded(child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: onEdit,
            child: Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(task.title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16,
                decoration: task.isCompleted ? TextDecoration.lineThrough : null,
                color: task.isCompleted ? Theme.of(context).colorScheme.onSurfaceVariant : null)),
              if (task.description.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(task.description, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              ],
              if (due != null) ...[
                const SizedBox(height: 8),
                Row(children: [
                  Icon(overdue ? Icons.warning_amber_rounded : Icons.schedule_rounded, size: 15,
                    color: overdue ? Colors.redAccent : AppTheme.purple),
                  const SizedBox(width: 5),
                  Flexible(child: Text('${MaterialLocalizations.of(context).formatShortDate(due)} · ${TimeOfDay.fromDateTime(due).format(context)}${overdue ? ' · OVERDUE' : ''}',
                    style: TextStyle(fontSize: 12, color: overdue ? Colors.redAccent : Theme.of(context).colorScheme.onSurfaceVariant))),
                ]),
              ],
            ])),
          )),
          PopupMenuButton<String>(
            tooltip: 'Task options',
            onSelected: (v) { if (v == 'edit') onEdit(); if (v == 'delete') onDelete(); },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: ListTile(leading: Icon(Icons.edit_outlined), title: Text('Edit'))),
              PopupMenuItem(value: 'delete', child: ListTile(leading: Icon(Icons.delete_outline), title: Text('Delete'))),
            ],
          ),
        ]),
      ),
    );
  }
}
