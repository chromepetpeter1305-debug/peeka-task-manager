class PeekaTask {
  const PeekaTask({
    required this.id,
    required this.title,
    required this.description,
    required this.isCompleted,
    required this.createdAt,
    this.dueAt,
    this.reminderId,
  });

  final String id;
  final String title;
  final String description;
  final bool isCompleted;
  final DateTime createdAt;
  final DateTime? dueAt;
  final int? reminderId;

  PeekaTask copyWith({
    String? title,
    String? description,
    bool? isCompleted,
    DateTime? dueAt,
    bool clearDueAt = false,
    int? reminderId,
    bool clearReminderId = false,
  }) => PeekaTask(
        id: id,
        title: title ?? this.title,
        description: description ?? this.description,
        isCompleted: isCompleted ?? this.isCompleted,
        createdAt: createdAt,
        dueAt: clearDueAt ? null : (dueAt ?? this.dueAt),
        reminderId: clearReminderId ? null : (reminderId ?? this.reminderId),
      );

  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'is_completed': isCompleted ? 1 : 0,
        'created_at': createdAt.toIso8601String(),
        'due_at': dueAt?.toIso8601String(),
        'reminder_id': reminderId,
      };

  factory PeekaTask.fromMap(Map<String, Object?> map) => PeekaTask(
        id: map['id'] as String,
        title: map['title'] as String,
        description: (map['description'] as String?) ?? '',
        isCompleted: (map['is_completed'] as int? ?? 0) == 1,
        createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(),
        dueAt: DateTime.tryParse(map['due_at'] as String? ?? ''),
        reminderId: map['reminder_id'] as int?,
      );
}
