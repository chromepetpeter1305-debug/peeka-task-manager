import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/task.dart';

class TaskDatabase {
  TaskDatabase._();
  static final TaskDatabase instance = TaskDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'peeka_tasks.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) => db.execute('''
        CREATE TABLE tasks(
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          description TEXT NOT NULL DEFAULT '',
          is_completed INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          due_at TEXT,
          reminder_id INTEGER
        )
      '''),
    );
    return _db!;
  }

  Future<List<PeekaTask>> getAll() async {
    final rows = await (await database).query('tasks', orderBy: 'created_at DESC');
    return rows.map(PeekaTask.fromMap).toList();
  }

  Future<void> insert(PeekaTask task) async =>
      (await database).insert('tasks', task.toMap(), conflictAlgorithm: ConflictAlgorithm.abort);

  Future<void> update(PeekaTask task) async =>
      (await database).update('tasks', task.toMap(), where: 'id = ?', whereArgs: [task.id]);

  Future<void> delete(String id) async =>
      (await database).delete('tasks', where: 'id = ?', whereArgs: [id]);
}
