import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'database/task_database.dart';
import 'services/notification_service.dart';
import 'screens/home_screen.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await TaskDatabase.instance.database;
  await NotificationService.instance.initialize();
  runApp(const PeekaApp());
}

class PeekaApp extends StatefulWidget {
  const PeekaApp({super.key});

  @override
  State<PeekaApp> createState() => _PeekaAppState();
}

class _PeekaAppState extends State<PeekaApp> {
  ThemeMode _themeMode = ThemeMode.dark;

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final isDark = prefs.getBool('darkTheme') ?? true;
    if (mounted) setState(() => _themeMode = isDark ? ThemeMode.dark : ThemeMode.light);
  }

  Future<void> setDarkMode(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkTheme', value);
    if (mounted) setState(() => _themeMode = value ? ThemeMode.dark : ThemeMode.light);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Peeka',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: _themeMode,
        home: HomeScreen(
          isDark: _themeMode == ThemeMode.dark,
          onThemeChanged: setDarkMode,
        ),
      );
}
