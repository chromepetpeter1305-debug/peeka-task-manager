Peeka logo asset used by flutter_launcher_icons. Regenerate launcher icons with: dart run flutter_launcher_icons
