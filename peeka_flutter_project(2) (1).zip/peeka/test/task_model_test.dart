import 'package:flutter_test/flutter_test.dart';
import 'package:peeka/models/task.dart';

void main() {
  test('task serializes and restores fields', () {
    final task = PeekaTask(
      id: 'abc', title: 'Study', description: 'Math chapter',
      isCompleted: true, createdAt: DateTime(2026, 1, 2, 3),
      dueAt: DateTime(2026, 1, 3, 4), reminderId: 12,
    );
    final restored = PeekaTask.fromMap(task.toMap());
    expect(restored.id, task.id);
    expect(restored.title, task.title);
    expect(restored.description, task.description);
    expect(restored.isCompleted, isTrue);
    expect(restored.dueAt, task.dueAt);
    expect(restored.reminderId, task.reminderId);
  });

  test('copyWith changes completion without changing task identity', () {
    final task = PeekaTask(id: 'x', title: 'Read', description: '',
      isCompleted: false, createdAt: DateTime(2026));
    final done = task.copyWith(isCompleted: true);
    expect(done.id, 'x');
    expect(done.isCompleted, isTrue);
  });
}
